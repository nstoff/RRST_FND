%execute simple plot
cd ("D:\Experimental_scripts\projet_interoception_2023\task1_RRST\task\helpers");
simplePMFplot
