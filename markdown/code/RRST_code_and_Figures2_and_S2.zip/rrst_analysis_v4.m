%%%
% rrst_analysis_v4.m / Nicolas Gninenko / Dec 2024
%
% Analysis script for RRST data generated from the RRST
% interoception project (inputs: saved .mat files).
%
% Original data is located in
% /Volumes/NMS_Aybek/Experiments/Original Results/27 - Interoception/RRST
%
% Questions: nicolas.gninenko@gmail.com
%%%


%%   Load workspace and patient's data of interest


if ismac && strcmp(getenv('USER'),'nicogn')
    data_Ppath = '/Users/nicogn/Documents/Bern buffer/Nicolas/RRST_Analysis/RRST/';
    %data_Excel = [data_Ppath '..' filesep 'Interoception_DATA_2024-01-15.xlsx'];
    %data_csv   = [data_Ppath '..' filesep 'Data.RRST_202404.csv'];
    data_csv   = [data_Ppath '..' filesep '..' filesep 'Code' filesep ...
        'RRST' filesep '240919 RRST Data Update' filesep 'Data.RRST_FINAL_20240910.csv']; %'Data.RRST_20240621.csv']; 
    addpath('/Users/nicogn/Documents/MATLAB/Palamedes');
    addpath(['/Users/nicogn/Documents/Bern buffer/Nicolas/' ...
        'Code/RespiroceptionMethodsPaper-main_NG/code/analyses/helperFunctions']);
else % specify the folder below with all 'P*' folders (e.g., P001)
    %data_Ppath = [pwd filesep]; % folder path (ending with / or \) of data (P* folders)
    %data_Excel = '...path\to\Excel\file.xlsx';
    %data_csv   = 'path\to\csv as above.csv';
    %
    % you also need to addpath() to the Palamedes toolbox (see above)
    % and to the helperFunctions of the original code from Nikolova et al.
end

%patients_datatable = readtable(data_Excel);
patients_datatable = readtable(data_csv);
participants_FND = patients_datatable(patients_datatable.group==1,:);
participants_HC  = patients_datatable(patients_datatable.group==0,:);

% exclude P63 from FND patients based on discussion with the patient,
% following agreement with Natascha & Petr & Selma (unusually good perf.)
participants_FND(35,:) = [];

RRSTdata_FND = struct; RRSTdata_HC  = struct;

for j = 1:height(participants_HC)
    tmp_pstr = ['P00' num2str(participants_HC.pcode(j))];
    if participants_HC.pcode(j)>9, tmp_pstr = ['P0' num2str(participants_HC.pcode(j))]; end
    if participants_HC.pcode(j)>99, tmp_pstr = ['P' num2str(participants_HC.pcode(j))]; end
    tmp_fpath = dir([data_Ppath tmp_pstr filesep 'RRS_' tmp_pstr '*.mat']);
    if ~isempty(tmp_fpath)
        tmp_fpath = [tmp_fpath(1).folder filesep tmp_fpath(1).name];
        RRSTdata_HC.(tmp_pstr) = load(tmp_fpath);
    else, tmp_fpath = dir([data_Ppath tmp_pstr filesep 'Aborted_RRS_' tmp_pstr '*.mat']);
        if ~isempty(tmp_fpath)
            tmp_fpath = [tmp_fpath(1).folder filesep tmp_fpath(1).name];
            RRSTdata_HC.(tmp_pstr) = load(tmp_fpath);
        else, fprintf(['\nUnable to load results (.mat) file for ' tmp_pstr '...\n']);
        end
    end
end

for j = 1:height(participants_FND)
    tmp_pstr = ['P00' num2str(participants_FND.pcode(j))];
    if participants_FND.pcode(j)>9, tmp_pstr = ['P0' num2str(participants_FND.pcode(j))]; end
    if participants_FND.pcode(j)>99, tmp_pstr = ['P' num2str(participants_FND.pcode(j))]; end
    tmp_fpath = dir([data_Ppath tmp_pstr filesep 'RRS_' tmp_pstr '*.mat']);
    if ~isempty(tmp_fpath)
        tmp_fpath = [tmp_fpath(1).folder filesep tmp_fpath(1).name];
        RRSTdata_FND.(tmp_pstr) = load(tmp_fpath);
    else, tmp_fpath = dir([data_Ppath tmp_pstr filesep 'Aborted_RRS_' tmp_pstr '*.mat']);
        if ~isempty(tmp_fpath)
            tmp_fpath = [tmp_fpath(1).folder filesep tmp_fpath(1).name];
            RRSTdata_FND.(tmp_pstr) = load(tmp_fpath);
        else, fprintf(['\nUnable to load results (.mat) file for ' tmp_pstr '...\n']);
        end
    end
end

clear j tmp_*;


%%   Compute a few metrics


tmp_fn1 = fieldnames(RRSTdata_FND);
tmp_fn2 = fieldnames(RRSTdata_HC);
Stim_FND = zeros(length(RRSTdata_FND.(tmp_fn1{1}).Results.trialN),height(participants_FND)-13); % temporary adjustment (-13) for missing data
Stim_HC  = zeros(length(RRSTdata_HC.(tmp_fn2{1}).Results.trialN),height(participants_HC)-1); % temporary adjustment (-1) for missing data

RT_FND = zeros(size(Stim_FND)); RT_HC  = zeros(size(Stim_HC));
Responses_FND= zeros(size(Stim_FND)); Responses_HC = zeros(size(Stim_HC));
PMF_inputs_FND = zeros(2,size(Stim_FND,2)); PMF_inputs_HC  = zeros(2,size(Stim_HC,2));

for j = 1:length(fieldnames(RRSTdata_FND))
    Stim_FND(:,j) = RRSTdata_FND.(tmp_fn1{j}).Results.Stim;
    RT_FND(:,j)   = RRSTdata_FND.(tmp_fn1{j}).Results.RT;
    Responses_FND(:,j) = RRSTdata_FND.(tmp_fn1{j}).Results.Resp;
    PMF_inputs_FND(:,j) = [RRSTdata_FND.(tmp_fn1{j}).stair.PM.threshold(end);...
        10.^(RRSTdata_FND.(tmp_fn1{j}).stair.PM.slope(end))];
end
for j = 1:length(fieldnames(RRSTdata_HC))
    Stim_HC(:,j)  = RRSTdata_HC.(tmp_fn2{j}).Results.Stim;
    RT_HC(:,j)   = RRSTdata_HC.(tmp_fn2{j}).Results.RT;
    Responses_HC(:,j) = RRSTdata_HC.(tmp_fn2{j}).Results.Resp;
    PMF_inputs_HC(:,j) = [RRSTdata_HC.(tmp_fn2{j}).stair.PM.threshold(end);...
        10.^(RRSTdata_HC.(tmp_fn2{j}).stair.PM.slope(end))];
end

clear tmp_fn* j;


%%   Average threshold estimate plots for all available FNDs vs HCs


if exist('tmp_f1','var') && ishandle(tmp_f1), close(tmp_f1); end
tmp_f1 = figure('Position',[90 100 1600 800]);
subplot(2,3,[1 2]);
plot(mean(Stim_FND,2,'omitnan'),'r-.o','MarkerSize',6,'MarkerFaceColor','r');
hold(tmp_f1.CurrentAxes,'on');
tmp_fill = fill([1:50 fliplr(1:50)]',...
        [mean(Stim_FND,2,'omitnan');fliplr(mean(Stim_FND,2,'omitnan')'-std(Stim_FND,0,2,'omitnan')')']','r');
tmp_fill.FaceAlpha = 0.05; tmp_fill.FaceColor = [1 0 0]; tmp_fill.EdgeAlpha = 0.05; tmp_fill.EdgeColor = [1 0 0];
tmp_fill = fill([1:50 fliplr(1:50)]',...
        [mean(Stim_FND,2,'omitnan');fliplr(mean(Stim_FND,2,'omitnan')'+std(Stim_FND,0,2,'omitnan')')']','r');
tmp_fill.FaceAlpha = 0.05; tmp_fill.FaceColor = [1 0 0]; tmp_fill.EdgeAlpha = 0.05; tmp_fill.EdgeColor = [1 0 0];
plot(mean(Stim_HC,2,'omitnan'),'b-.o','MarkerSize',6,'MarkerFaceColor','b');
tmp_fill = fill([1:50 fliplr(1:50)]',...
        [mean(Stim_HC,2,'omitnan');fliplr(mean(Stim_HC,2,'omitnan')'-std(Stim_HC,0,2,'omitnan')')']','r');
tmp_fill.FaceAlpha = 0.05; tmp_fill.FaceColor = [0 0 1]; tmp_fill.EdgeAlpha = 0.05; tmp_fill.EdgeColor = [0 0 1];
tmp_fill = fill([1:50 fliplr(1:50)]',...
        [mean(Stim_HC,2,'omitnan');fliplr(mean(Stim_HC,2,'omitnan')'+std(Stim_HC,0,2,'omitnan')')']','r');
tmp_fill.FaceAlpha = 0.05; tmp_fill.FaceColor = [0 0 1]; tmp_fill.EdgeAlpha = 0.05; tmp_fill.EdgeColor = [0 0 1];
axis([-1 52 0 18]); xticks(0:5:50); yticks(1:2:15);
tmp_f1.CurrentAxes.YMinorGrid = 'on'; tmp_f1.CurrentAxes.XGrid = 'on';
tmp_f1.CurrentAxes.Box = 'on'; tmp_f1.CurrentAxes.FontSize = 12;
tmp_f1.CurrentAxes.FontName = 'Basis Grotesque Pro'; % can be commented out if problematic fonts arise
%legend('FND','','','HC','Location','best');
bar(sum(Responses_FND<1,2,'omitnan')/size(Responses_FND,2)*10,'FaceColor',[1 0 0],'FaceAlpha',.05);
bar(sum(Responses_HC<1,2,'omitnan')/size(Responses_HC,2)*10,'FaceColor',[0 0 1],'FaceAlpha',.05);
legend(['FND (n = ' num2str(size(Responses_FND,2)) ')'],'','',['HC (n = ' num2str(size(Responses_HC,2)) ')'],'','',...
    'Norm. #errors (FND)','Norm. #errors (HC)',...
    'Location','east','FontSize',12);
ylabel({'Resistance (mm)','Normalized # of errors'},'FontSize',14);
xlabel('Trials','FontSize',14);
title(['Average (±SD) threshold estimate by trial (' num2str(size(Responses_HC,1)) ' trials, ' ...
    num2str(size(Responses_HC,2)) ' HCs, ' num2str(size(Responses_FND,2)) ' FNDs)'],'FontSize',16,'FontWeight','normal');

subplot(2,3,4);
%bar([mean(mean(RT_FND,'omitnan'))+mean(std(RT_FND,'omitnan')) ...
%    mean(mean(RT_HC,'omitnan'))+mean(std(RT_HC,'omitnan'))],'b','FaceAlpha',0.05,'BarWidth',0.25);
%hold on;
bar([mean(mean(RT_FND(Responses_FND>0),'omitnan')) ...
    mean(mean(RT_FND(Responses_FND==0),'omitnan'))],...
    'FaceColor',[.9 0 0],'FaceAlpha',0.2);
hold(tmp_f1.CurrentAxes,'on');
rectangle('Position',[1-.5/2 mean(mean(RT_FND(Responses_FND>0),'omitnan')) ...
    .5 mean(std(RT_FND(Responses_FND>0),'omitnan')/sqrt(length(RT_FND(Responses_FND>0))))],'FaceColor',[1 0 0 .05]);
rectangle('Position',[1-.5/2 mean(mean(RT_FND(Responses_FND>0),'omitnan'))-...
    mean(std(RT_FND(Responses_FND>0),'omitnan')/sqrt(length(RT_FND(Responses_FND>0)))) ...
    .5 mean(std(RT_FND(Responses_FND>0),'omitnan')/sqrt(length(RT_FND(Responses_FND>0))))],'FaceColor',[1 0 0 .05]);
rectangle('Position',[2-.5/2 mean(mean(RT_FND(Responses_FND==0),'omitnan')) ...
    .5 mean(std(RT_FND(Responses_FND==0),'omitnan')/sqrt(length(RT_FND(Responses_FND==0))))],'FaceColor',[1 0 0 .05]);
rectangle('Position',[2-.5/2 mean(mean(RT_FND(Responses_FND==0),'omitnan'))-...
    mean(std(RT_FND(Responses_FND==0),'omitnan')/sqrt(length(RT_FND(Responses_FND==0)))) ...
    .5 mean(std(RT_FND(Responses_FND==0),'omitnan')/sqrt(length(RT_FND(Responses_FND==0))))],'FaceColor',[1 0 0 .05]);
axis([0 3 0 2.4]);
yticks(0:.2:2.4); tmp_f1.CurrentAxes.YGrid = 'on';
ylabel('Response Time (s)','FontSize',14);
xticklabels({'Correct','Incorrect'});
tmp_f1.CurrentAxes.FontSize = 14;
title({['FND — Response time \times Accuracy (n = ' num2str(size(Responses_FND,2)) ')'],'Mean ± stderr'},...
    'FontSize',16,'Interpreter','tex','FontWeight','normal');
line([1 2; 1 1; 2 2]',[2 2; 1.95 2; 1.95 2]','LineWidth',1.2,'Color','black');
text(1.5,2.1,'*','FontSize',14,'FontName','Basis Grotesque Pro','FontWeight','Normal');


subplot(2,3,5);
%bar([mean(mean(RT_FND,'omitnan'))+mean(std(RT_FND,'omitnan')) ...
%    mean(mean(RT_HC,'omitnan'))+mean(std(RT_HC,'omitnan'))],'b','FaceAlpha',0.05,'BarWidth',0.25);
%hold on;
bar([mean(mean(RT_HC(Responses_HC>0),'omitnan')) ...
    mean(mean(RT_HC(Responses_HC==0),'omitnan'))],...
    'FaceColor',[0 0 .9],'FaceAlpha',0.2);
hold(tmp_f1.CurrentAxes,'on');
rectangle('Position',[1-.5/2 mean(mean(RT_HC(Responses_HC>0),'omitnan')) ...
    .5 mean(std(RT_HC(Responses_HC>0),'omitnan')/sqrt(length(RT_HC(Responses_HC>0))))],'FaceColor',[0 0 1 .05]);
rectangle('Position',[1-.5/2 mean(mean(RT_HC(Responses_HC>0),'omitnan'))-...
    mean(std(RT_HC(Responses_HC>0),'omitnan')/sqrt(length(RT_HC(Responses_HC>0)))) ...
    .5 mean(std(RT_HC(Responses_HC>0),'omitnan')/sqrt(length(RT_HC(Responses_HC>0))))],'FaceColor',[0 0 1 .05]);
rectangle('Position',[2-.5/2 mean(mean(RT_HC(Responses_HC==0),'omitnan')) ...
    .5 mean(std(RT_HC(Responses_HC==0),'omitnan')/sqrt(length(RT_HC(Responses_HC==0))))],'FaceColor',[0 0 1 .05]);
rectangle('Position',[2-.5/2 mean(mean(RT_HC(Responses_HC==0),'omitnan'))-...
    mean(std(RT_HC(Responses_HC==0),'omitnan')/sqrt(length(RT_HC(Responses_HC==0)))) ...
    .5 mean(std(RT_HC(Responses_HC==0),'omitnan')/sqrt(length(RT_HC(Responses_HC==0))))],'FaceColor',[0 0 1 .05]);
axis([0 3 0 2.4]);
yticks(0:.2:2.4); tmp_f1.CurrentAxes.YGrid = 'on';
ylabel('Response Time (s)','FontSize',14);
xticklabels({'Correct','Incorrect'});
tmp_f1.CurrentAxes.FontSize = 14;
title({['HC — Response time \times Accuracy (n = ' num2str(size(Responses_HC,2)) ')'],'Mean ± stderr'},...
    'FontSize',16,'Interpreter','tex','FontWeight','normal');
line([1 2; 1 1; 2 2]',[2 2; 1.95 2; 1.95 2]','LineWidth',1.2,'Color','black');
text(1.5,2.1,'*','FontSize',14,'FontName','Basis Grotesque Pro','FontWeight','Normal');


subplot(2,3,3);
for j = 1:size(Stim_FND,2)
    PF          = @PAL_Weibull;
    gamma       = 0.5;  % as fixed also in our prior parameters
    lambda      = 0.03; % same
    stimuli     = Stim_FND(:,j); %psidata(psidata.ID==thisSubId, :).stimLevel;
    responses   = Responses_FND(:,j); %psidata(psidata.ID==thisSubId, :).response;
    if ~isempty(find(isnan(responses),1)), continue; end % skip current vector if NaN are present (i.e., aborted trials are ignored)
    nPresented  = ones(size(stimuli)); %ones(size(stimuli));
    [SL, NP, OON] = PAL_PFML_GroupTrialsbyX(stimuli',responses',nPresented');
    % SL stim levels, NP num positive, OON out of num
    hold(tmp_f1.CurrentAxes,'on');
    for SR = 1:length(SL(OON~=0))
        plot(SL(SR),NP(SR)/OON(SR),'wo','MarkerFaceColor',[1 0 0],'markersize',10*sqrt(OON(SR)./sum(OON)));
    end
    plot(0:.01:max(stimuli)+1, ...
        PF([PMF_inputs_FND(1,j) PMF_inputs_FND(2,j) ...
        gamma lambda],0:.01:max(stimuli)+1),'Color',[1 0 0 .5],'LineWidth',.75);
end
for j = 1:size(Stim_HC,2)
    PF          = @PAL_Weibull;
    gamma       = 0.5;  % as fixed also in our prior parameters
    lambda      = 0.03; % same
    stimuli     = Stim_HC(:,j); %psidata(psidata.ID==thisSubId, :).stimLevel;
    responses   = Responses_HC(:,j); %psidata(psidata.ID==thisSubId, :).response;
    if ~isempty(find(isnan(responses),1)), continue; end % skip current vector if NaN are present (i.e., aborted trials are ignored)
    nPresented  = ones(size(stimuli)); %ones(size(stimuli));
    [SL, NP, OON] = PAL_PFML_GroupTrialsbyX(stimuli',responses',nPresented');
    % SL stim levels, NP num positive, OON out of num
    %hold(tmp_f1.CurrentAxes,'on');
    for SR = 1:length(SL(OON~=0))
        plot(SL(SR),NP(SR)/OON(SR),'wo','MarkerFaceColor',[0 0 1],'markersize',10*sqrt(OON(SR)./sum(OON)));
    end
    plot(0:.01:max(stimuli)+1, ...
        PF([PMF_inputs_HC(1,j) PMF_inputs_HC(2,j) ...
        gamma lambda],0:.01:max(stimuli)+1),'Color',[0 0 1 .5],'LineWidth',.75)
end
tmp_f1.CurrentAxes.FontSize = 12;
xlabel('Resistance (mm)','FontSize',14);
ylabel('p(correct response)','FontSize',14);
yticks(0:.25:1); xticks(1:2:17);
title('Individual PMF fits','FontSize',16,'FontWeight','normal');
%legend('FND','HC');
camroll(90);

subplot(2,3,6);
for j = 1:size(Stim_FND,2)
    PF          = @PAL_Weibull;
    gamma       = 0.5;  % as fixed also in our prior parameters
    lambda      = 0.03; % same
    stimuli     = Stim_FND(:,j); %psidata(psidata.ID==thisSubId, :).stimLevel;
    %responses   = Responses_FND(:,j); %psidata(psidata.ID==thisSubId, :).response;
    %nPresented  = ones(size(stimuli)); %ones(size(stimuli));
    %[SL, NP, OON] = PAL_PFML_GroupTrialsbyX(stimuli',responses',nPresented');
    % SL stim levels, NP num positive, OON out of num
    hold(tmp_f1.CurrentAxes,'on');
    plot(0:.01:max(stimuli)+1, ...
        PF([PMF_inputs_FND(1,j) PMF_inputs_FND(2,j) ...
        gamma lambda],0:.01:max(stimuli)+1),'Color',[.2 0.2 0.2 .2],'LineWidth',.75);
end

% Mean PMF
PF          = @PAL_Weibull;
gamma       = 0.5;
lambda      = 0.03;
grain       = 50;
sgrid.alpha  = linspace(PF([6 2 0 0],.1,'inverse'),PF([6 2 0 0],.9999,'inverse'),grain);
sgrid.beta   = linspace(log10(1),log10(16),grain);
sgrid.gamma  = gamma;
sgrid.lambda = lambda;
stimuli     = Stim_FND(:,j);
responses   = Responses_FND(:,j);
nPresented  = ones(size(stimuli));
maxStim     = max(stimuli);
hold on;

% bayesian fit of PMF
[SL, NP, OON] = PAL_PFML_GroupTrialsbyX(stimuli',responses',nPresented');
[paramsValues, ~] = PAL_PFBA_Fit(SL, NP, OON, sgrid, PF);
threshEst   = paramsValues(1,1);
slopeEst    = 10.^(paramsValues(1,2));

% Add reference line for threshold level of 75% correct
y1 = PF([threshEst slopeEst gamma lambda],0:.01:max(stimuli)+1);        % Psychometric function fit
y2 = 0.75 * ones(size(y1));                                             % Threshold level                
x1 = 0:.01:(max(stimuli)+1);                                            
[xInt,yInt] = intersections(x1,y1,x1,y2);

% Add a vertical line to indicate the threshold
plot([0 xInt],[yInt yInt],'--','Color','red','linewidth',.5)
plot([xInt xInt],[0 .75],'--','Color','red','linewidth',.5)

% Plot PMF
plot([0:.01:max(stimuli)+1], PF([threshEst slopeEst gamma lambda],0:.01:max(stimuli)+1),...
    'Color','blue','linewidth',.5)

% Add marker at threshold and text, '[Threshold:  num2str(round(xInt))]'
plot(xInt,.75,'wo','markerfacecolor','green','markersize', 14)
xIntScal        = (xInt*100/maxStim);                                   % scale from mm to % obstruction
threshLabel     = ['\alpha: ', num2str(round(xIntScal,2))];
text(4.2,.785,threshLabel,'FontSize',14);

tmp_f1.CurrentAxes.FontSize = 12;
axis([0 18 .5 1]);
xlabel('Resistance (mm)','FontSize',14);
ylabel('p(correct response)','FontSize',14);
yticks(0.5:.1:1); xticks(1:2:17);
title('Group PMF fit','FontSize',16);


%%   Respiration sensitivity vs metacognitive scores


% Compute each vector of confidence ratings for both groups, rounded (floor/ceil)
% to the closest value to have a range of 101 possible values (i.e., [0
% 100]), since a finite range is required to compute type 2 AUC according
% to Fleming & Lau (2014) [How to measure metacognition]

Participants_HC_names = fieldnames(RRSTdata_HC);
Participants_FND_names= fieldnames(RRSTdata_FND); % get all patient IDs
%Participants_FND_names(35) = []; % remove outlier as discussed previously
ConfidenceRatings_HC = zeros(length(Participants_HC_names),size(RT_HC,1));
ConfidenceRatings_FND= zeros(length(Participants_FND_names),size(RT_FND,1));
AUROC2_HC = zeros(1,size(RT_HC,2));
AUROC2_FND = zeros(1,size(RT_FND,2));

for j = 1:length(Participants_HC_names)
    ConfidenceRatings_HC(j,:) = round(RRSTdata_HC.(Participants_HC_names{j}).Results.ConfResp)';
    AUROC2_HC(1,j) = type2roc(Responses_HC(:,j)',ConfidenceRatings_HC(j,:),100); % here it is 100 as max of conf. rating
end
for j = 1:length(Participants_FND_names)
    ConfidenceRatings_FND(j,:) = round(RRSTdata_FND.(Participants_FND_names{j}).Results.ConfResp)';
    AUROC2_FND(1,j) = type2roc(Responses_FND(:,j)',ConfidenceRatings_FND(j,:),100); % here it is 100 as max of conf. rating
end

if exist('tmp_f5','var') && ishandle(tmp_f5), close(tmp_f5); end
tmp_f5 = figure('Position',[-1400 140 800 600]);
%subplot(2,2,1);
bar(1,mean(AUROC2_HC),'FaceColor',[0 0 .9],'FaceAlpha',0.2); hold(tmp_f5.CurrentAxes,'on');
rectangle('Position',[1-.5/2 mean(AUROC2_HC)-std(AUROC2_HC) .5 std(AUROC2_HC)],'FaceColor',[0 0 1 .1]);
rectangle('Position',[1-.5/2 mean(AUROC2_HC) .5 std(AUROC2_HC)],'FaceColor',[0 0 1 .1]);
bar(2,mean(AUROC2_FND),'FaceColor',[.9 0 0],'FaceAlpha',0.2);
rectangle('Position',[2-.5/2 mean(AUROC2_FND)-std(AUROC2_FND) .5 std(AUROC2_FND)],'FaceColor',[1 0 0 .1]);
rectangle('Position',[2-.5/2 mean(AUROC2_FND) .5 std(AUROC2_FND)],'FaceColor',[1 0 0 .1]);

scatter(1,AUROC2_HC,34,[0 0 1],'filled','MarkerFaceAlpha',.5);
scatter(2,AUROC2_FND,34,[1 0 0],'filled','MarkerFaceAlpha',.5);

axis([0 3 0 1]); xticks(1:2);
yticks(0.1:.1:.9); tmp_f5.CurrentAxes.YGrid = 'on';
tmp_f5.CurrentAxes.FontSize = 12;
tmp_f5.CurrentAxes.YLabel.FontSize = 16;
%tmp_f5.CurrentAxes.YLabel.String = {'AUROC2 value',...
%    '\fontsize{12} computed as per Fleming & Lau (2014)'};
tmp_f5.CurrentAxes.YLabel.String = 'AUROC2 value';
%tmp_f5.CurrentAxes.YLabel.Interpreter = 'latex';
xticklabels({'HC','FND'});
tmp_f5.CurrentAxes.YAxis.Label.Position(1) = tmp_f5.CurrentAxes.YAxis.Label.Position(1)-0.05;

tmp_f5.CurrentAxes.Title.String = {'Metacognitive sensitivities of HCs \itvs\rm FND patients',...
    ['\fontsize{12} Computed as the difference between two areas ' ...
    'under the curves (AUROC2), as per Fleming & Lau (2014)']};
%tmp_f5.CurrentAxes.Title.FontName = 'Basis Grotesque Pro';
tmp_f5.CurrentAxes.Title.FontWeight = 'Normal';
tmp_f5.CurrentAxes.Title.FontSize = 20;

line([1 2],[.85 .85],'LineWidth',1.5,'Color',[0 0 0 0.9],'LineStyle','-');
line([1 1],[.835 .851],'LineWidth',1.5,'Color',[0 0 0 0.9],'LineStyle','-');
line([2 2],[.835 .851],'LineWidth',1.5,'Color',[0 0 0 0.9],'LineStyle','-');
text(1.45,.88,'n.s.','FontSize',14,'FontWeight','Normal');%,'FontName','Basis Grotesque Pro');

text(.73,.15,['std = ' num2str(std(AUROC2_HC))],'FontSize',16,'FontWeight','Normal');
text(1.78,.15,['std = ' num2str(std(AUROC2_FND))],'FontSize',16,'FontWeight','Normal');


%%   Plot average ROCs for HCs/FNDs (e.g., for visual check)


if exist('tmp_f6','var') && ishandle(tmp_f6), close(tmp_f6); end
tmp_f6 = figure('Position',[-1800 140 1600 600]);
subplot(121);
line([0 1],[0 1],'LineWidth',3,'Color',[0 0 0 .9],'LineStyle','-');
hold(tmp_f6.CurrentAxes,'on');
for j = 1:length(Participants_HC_names)
    [~,tmp_H2,tmp_FA2] = type2roc(Responses_HC(:,j)',ConfidenceRatings_HC(j,:),100);
    plot(tmp_FA2,tmp_H2,'Marker','sq','MarkerSize',2,'MarkerFaceColor',[0 0 .9],...
        'MarkerEdgeColor','None','LineWidth',.8,'Color',[0 0 .9 .9],'LineStyle','-.');
end
axis([0 1 0 1],'square');
tmp_f6.CurrentAxes.Box = 'on';
xticks(0:.1:1); yticks(.1:.1:1);
tmp_f6.CurrentAxes.FontSize = 12;
tmp_f6.CurrentAxes.XAxis.Label.String = ' \itp\rm(confidence | incorrect) ';
tmp_f6.CurrentAxes.YAxis.Label.String = ' \itp\rm(confidence | correct) ';
tmp_f6.CurrentAxes.XAxis.Label.FontSize = 18; tmp_f6.CurrentAxes.YAxis.Label.FontSize = 18;
tmp_f6.CurrentAxes.XGrid = 'on'; tmp_f6.CurrentAxes.YGrid = 'on';
tmp_f6.CurrentAxes.YAxis.Label.Position(1) = tmp_f6.CurrentAxes.YAxis.Label.Position(1)-0.015;
tmp_f6.CurrentAxes.XAxis.Label.Position(2) = tmp_f6.CurrentAxes.XAxis.Label.Position(2)-0.015;
legend('',[' HC (N = ' num2str(length(Participants_HC_names)) ')'],'Location','NorthWest',...
    'FontSize',18,'FontWeight','Normal');
tmp_f6.CurrentAxes.Title.String = {'Metacognitive sensitivity curves (ROC) of HCs',...
    '\fontsize{12} Computed as per Fleming & Lau (2014)'};
%tmp_f6.CurrentAxes.Title.FontName = 'Basis Grotesque Pro';
tmp_f6.CurrentAxes.Title.FontWeight = 'Normal';
tmp_f6.CurrentAxes.Title.FontSize = 18;

subplot(122);
line([0 1],[0 1],'LineWidth',3,'Color',[0 0 0 .9],'LineStyle','-');
hold(tmp_f6.CurrentAxes,'on');
for j = 1:length(Participants_FND_names)
    [~,tmp_H2,tmp_FA2] = type2roc(Responses_FND(:,j)',ConfidenceRatings_FND(j,:),100);
    plot(tmp_FA2,tmp_H2,'Marker','sq','MarkerSize',2,'MarkerFaceColor',[.9 0 0],...
        'MarkerEdgeColor','None','LineWidth',.8,'Color',[.9 0 0 .9],'LineStyle','-.');
end
axis([0 1 0 1],'square');
tmp_f6.CurrentAxes.Box = 'on';
xticks(0:.1:1); yticks(.1:.1:1);
tmp_f6.CurrentAxes.FontSize = 12;
tmp_f6.CurrentAxes.XAxis.Label.String = ' \itp\rm(confidence | incorrect) ';
tmp_f6.CurrentAxes.YAxis.Label.String = ' \itp\rm(confidence | correct) ';
tmp_f6.CurrentAxes.XAxis.Label.FontSize = 18; tmp_f6.CurrentAxes.YAxis.Label.FontSize = 18;
tmp_f6.CurrentAxes.XGrid = 'on'; tmp_f6.CurrentAxes.YGrid = 'on';
tmp_f6.CurrentAxes.YAxis.Label.Position(1) = tmp_f6.CurrentAxes.YAxis.Label.Position(1)-0.015;
tmp_f6.CurrentAxes.XAxis.Label.Position(2) = tmp_f6.CurrentAxes.XAxis.Label.Position(2)-0.015;
legend('',[' FND (N = ' num2str(length(Participants_FND_names)) ')'],'Location','NorthWest',...
    'FontSize',18,'FontWeight','Normal');
tmp_f6.CurrentAxes.Title.String = {'Metacognitive sensitivity curves (ROC) of FND patients',...
    '\fontsize{12} Computed as per Fleming & Lau (2014)'};
%tmp_f6.CurrentAxes.Title.FontName = 'Basis Grotesque Pro';
tmp_f6.CurrentAxes.Title.FontWeight = 'Normal';
tmp_f6.CurrentAxes.Title.FontSize = 18;


%%   Plot PMF fits per group (update for Fig 2)


%if exist('tmp_f6_1','var') && ishandle(tmp_f6_1), close(tmp_f6_1); end
tmp_f6_1 = figure('Position',[-1800 140 1600 600]);
gamma  =  0.5; % as fixed also in our prior parameters
lambda = 0.03; % same

PF     = @PAL_Weibull;

subplot(121); % for HCs

for j = 1:size(Stim_HC,2) % plot (NO PARAMS FITTING HERE!) PF (Weibull) curves with last parameters for every HC (see PMF_inputs_HC)
    stimuli     = Stim_HC(:,j); %psidata(psidata.ID==thisSubId, :).stimLevel;
    %responses   = Responses_FND(:,j); %psidata(psidata.ID==thisSubId, :).response;
    %nPresented  = ones(size(stimuli)); %ones(size(stimuli));
    %[SL, NP, OON] = PAL_PFML_GroupTrialsbyX(stimuli',responses',nPresented');
    % SL stim levels, NP num positive, OON out of num
    hold(tmp_f6_1.CurrentAxes,'on');
    plot(min(stimuli):.01:max(stimuli), ...
        PF([PMF_inputs_HC(1,j) PMF_inputs_HC(2,j) ...
        gamma lambda],min(stimuli):.01:max(stimuli)),'Color',[.2 0.2 0.2 .2],'LineWidth',0.75);
end

% now fit the group PMF the same way as done in Nikolova et al. (2022)
paramsFree = [1 1 0 0]; % which parameters to fit (free -> alpha beta)
% PF does not change from above
searchGrid = struct; % see 'multSubPMF.m' in '.../tasks/helpers/' for more details on the search grid
%searchGrid.alpha = linspace(0,100,201); % for alpha
searchGrid.alpha = linspace(5,15,200); % for alpha - adapted
%searchGrid.beta = linspace(log10(1),log10(16),201); % for beta (/!\ wrong in Nikolova et al.'s code)
searchGrid.beta = 10.^(linspace(-1,5,200));
searchGrid.gamma = gamma;
searchGrid.lambda = lambda;

stimlevels_HC = unique(Stim_HC(~isnan(Stim_HC)))'; % same as min(min(Stim_HC)):1:max(max(Stim_HC));
%outofnum_HC   = hist(Stim_HC(:),stimlevels_HC); % alternatively we use histcounts (more recent function) below
outofnum_HC   = histcounts(Stim_HC(:),[stimlevels_HC max(stimlevels_HC)+1]);
%numpos_HC     = hist(Stim_HC(Responses_HC==1),stimlevels_HC); % alternatively we use histcounts (more recent function) below
numpos_HC     = histcounts(Stim_HC(Responses_HC==1),[stimlevels_HC max(stimlevels_HC)+1]);

%paramsValues_fit = PAL_PFML_Fit(stimlevels_HC, numpos_HC, ...
%    outofnum_HC, searchGrid, paramsFree, PF); % [paramsValues_fit LL exitflag]
%plot(5:.01:stimlevels_HC(end), ...
%        PF([paramsValues_fit(1,1) paramsValues_fit(1,2) ...
%        gamma lambda],5:.01:stimlevels_HC(end)),'Color',[.2 0.2 0.2 .7],'LineWidth',2);

plot(5:.01:stimlevels_HC(end), ...
        PF([mean(PMF_inputs_HC(1,:)) 10^(mean(log10(PMF_inputs_HC(2,:)))) ...
        gamma lambda],5:.01:stimlevels_HC(end)),'Color',[.2 0.2 0.2 .7],'LineWidth',2.5);

axis([5 18 0.47 1],'square');
tmp_f6_1.CurrentAxes.Box = 'on';
xticks(6:17); yticks(.5:.1:1);
tmp_f6_1.CurrentAxes.FontSize = 12;
%tmp_f6_1.CurrentAxes.XAxis.Label.String = ' \itp\rm(confidence | incorrect) ';
%tmp_f6_1.CurrentAxes.YAxis.Label.String = ' \itp\rm(confidence | correct) ';
tmp_f6_1.CurrentAxes.XAxis.Label.FontSize = 18; tmp_f6_1.CurrentAxes.YAxis.Label.FontSize = 18;
tmp_f6_1.CurrentAxes.XGrid = 'on'; tmp_f6_1.CurrentAxes.YGrid = 'on';
%tmp_f6_1.CurrentAxes.YAxis.Label.Position(1) = tmp_f6_1.CurrentAxes.YAxis.Label.Position(1)-0.015;
%tmp_f6_1.CurrentAxes.XAxis.Label.Position(2) = tmp_f6_1.CurrentAxes.XAxis.Label.Position(2)-0.015;
%legend('',[' HC (N = ' num2str(length(Participants_HC_names)) ')'],'Location','NorthWest',...
%    'FontSize',18,'FontWeight','Normal');
%tmp_f6_1.CurrentAxes.Title.String = {'Metacognitive sensitivity curves (ROC) of HCs',...
%    '\fontsize{12} Computed as per Fleming & Lau (2014)'};
%tmp_f6_1.CurrentAxes.Title.FontName = 'Basis Grotesque Pro';
tmp_f6_1.CurrentAxes.Title.FontWeight = 'Normal';
tmp_f6_1.CurrentAxes.Title.FontSize = 18;

subplot(122);

for j = 1:size(Stim_FND,2)
    stimuli     = Stim_FND(:,j); %psidata(psidata.ID==thisSubId, :).stimLevel;
    %responses   = Responses_FND(:,j); %psidata(psidata.ID==thisSubId, :).response;
    %nPresented  = ones(size(stimuli)); %ones(size(stimuli));
    %[SL, NP, OON] = PAL_PFML_GroupTrialsbyX(stimuli',responses',nPresented');
    % SL stim levels, NP num positive, OON out of num
    hold(tmp_f6_1.CurrentAxes,'on');
    plot(min(stimuli):.01:max(stimuli), ...
        PF([PMF_inputs_FND(1,j) PMF_inputs_FND(2,j) ...
        gamma lambda],min(stimuli):.01:max(stimuli)),'Color',[.9 0.2 0.2 .2],'LineWidth',0.75);
end

stimlevels_FND = unique(Stim_FND(~isnan(Stim_FND)))'; % same as min(min(Stim_FND)):1:max(max(Stim_FND));
%outofnum_FND   = hist(Stim_FND(:),stimlevels_FND); % alternatively we use histcounts (more recent function) below
outofnum_FND   = histcounts(Stim_FND(:),[stimlevels_FND max(stimlevels_FND)+1]);
%numpos_FND     = hist(Stim_FND(Responses_FND==1),stimlevels_FND); % alternatively we use histcounts (more recent function) below
numpos_FND     = histcounts(Stim_FND(Responses_FND==1),[stimlevels_FND max(stimlevels_FND)+1]);

%StimLevels = unique(ResultsArray(:,stimIntensity))';
%OutOfNum = hist(ResultsArray(:,stimIntensity), StimLevels);
%NumPos = hist( ResultsArray(logical(ResultsArray(:,responsesAccuracy)==1),stimIntensity), StimLevels );      

%paramsValues_fit = PAL_PFML_Fit(stimlevels_FND, numpos_FND, ...
%    outofnum_FND, searchGrid, paramsFree, PF); % [paramsValues_fit LL exitflag]
%plot(5:.01:stimlevels_FND(end), ...
%        PF([paramsValues_fit(1,1) paramsValues_fit(1,2) ...
%        gamma lambda],5:.01:stimlevels_FND(end)),'Color',[.9 0.2 0.2 .7],'LineWidth',2);

plot(5:.01:stimlevels_FND(end), ...
        PF([mean(PMF_inputs_FND(1,:)) 10^(mean(log10(PMF_inputs_FND(2,:)))) ...
        gamma lambda],5:.01:stimlevels_FND(end)),'Color',[.9 0.2 0.2 .7],'LineWidth',2.5);

axis([5 18 0.47 1],'square');
tmp_f6_1.CurrentAxes.Box = 'on';
xticks(6:17); yticks(.5:.1:1);
tmp_f6_1.CurrentAxes.FontSize = 12;
%tmp_f6_1.CurrentAxes.XAxis.Label.String = ' \itp\rm(confidence | incorrect) ';
%tmp_f6_1.CurrentAxes.YAxis.Label.String = ' \itp\rm(confidence | correct) ';
tmp_f6_1.CurrentAxes.XAxis.Label.FontSize = 18; tmp_f6_1.CurrentAxes.YAxis.Label.FontSize = 18;
tmp_f6_1.CurrentAxes.XGrid = 'on'; tmp_f6_1.CurrentAxes.YGrid = 'on';
%tmp_f6_1.CurrentAxes.YAxis.Label.Position(1) = tmp_f6_1.CurrentAxes.YAxis.Label.Position(1)-0.015;
%tmp_f6_1.CurrentAxes.XAxis.Label.Position(2) = tmp_f6_1.CurrentAxes.XAxis.Label.Position(2)-0.015;
%legend('',[' FND (N = ' num2str(length(Participants_FND_names)) ')'],'Location','NorthWest',...
%    'FontSize',18,'FontWeight','Normal');
%tmp_f6_1.CurrentAxes.Title.String = {'Metacognitive sensitivity curves (ROC) of FND patients',...
%    '\fontsize{12} Computed as per Fleming & Lau (2014)'};
%tmp_f6_1.CurrentAxes.Title.FontName = 'Basis Grotesque Pro';
tmp_f6_1.CurrentAxes.Title.FontWeight = 'Normal';
tmp_f6_1.CurrentAxes.Title.FontSize = 18;


%%   Resp. sensitivity  vs  metacognitive scores


if exist('tmp_f7','var') && ishandle(tmp_f7), close(tmp_f7); end
tmp_f7 = figure('Position',[920 100 800 600]);
scatter(participants_HC.rrst_sensitivity,AUROC2_HC,42,[0 0 .9],'filled',...
    'Marker','o','MarkerFaceAlpha',0.7);
hold(tmp_f7.CurrentAxes,'on');
scatter(participants_FND.rrst_sensitivity,AUROC2_FND,42,[.9 0 0],'filled',...
    'Marker','sq','MarkerFaceAlpha',0.7);
axis([-1 10 .25 .75],'square');
xticks(0:9); yticks(.3:.05:.7);
yticklabels({'0.3','','0.4','','0.5','','0.6','','0.7'});
tmp_f7.CurrentAxes.Box = 'On'; tmp_f7.CurrentAxes.FontSize = 16;
tmp_f7.CurrentAxes.XGrid = 'On'; tmp_f7.CurrentAxes.YGrid = 'On';
tmp_f7.CurrentAxes.XAxis.Label.String = 'Respiratory sensitivity (a.u.)';
%tmp_f7.CurrentAxes.XAxis.Label.FontSize = 16;
tmp_f7.CurrentAxes.YAxis.Label.String = 'Metacognitive sensitivity (AUROC2)';
%tmp_f7.CurrentAxes.YAxis.Label.FontSize = 16;
tmp_f7.CurrentAxes.YAxis.Label.Position(1) = tmp_f7.CurrentAxes.YAxis.Label.Position(1)-0.25;
tmp_f7.CurrentAxes.XAxis.Label.Position(2) = tmp_f7.CurrentAxes.XAxis.Label.Position(2)-0.01;

tmp_PP = polyfit(participants_HC.rrst_sensitivity,AUROC2_HC,1);
plot([-.5;participants_HC.rrst_sensitivity;9.5],...
    tmp_PP(1)*[-.5;participants_HC.rrst_sensitivity;9.5]+tmp_PP(2),...
    '-','Color',[0 0 .9],'LineWidth',1.3); % HC
tmp_PP = polyfit(participants_FND.rrst_sensitivity,AUROC2_FND,1);
plot([-.5;participants_FND.rrst_sensitivity;9.5],...
    tmp_PP(1)*[-.5;participants_FND.rrst_sensitivity;9.5]+tmp_PP(2),...
    '-','Color',[.9 0 0],'LineWidth',1.3); % HC
legend([' HCs (N = ' num2str(length(Participants_HC_names)) ')'],...
    [' FND (N = ' num2str(length(Participants_FND_names)) ')'],...
        ' HCs (linear interp.)',...
    ' FND (linear interp.)','FontSize',16,'Location','SouthEast');
tmp_f7.CurrentAxes.Title.String = ...
    'Metacognitive \itvs\rm respiratory sensitivities for HCs \itvs\rm FND patients';
%tmp_f7.CurrentAxes.Title.String = ...
%    {'Metacognitive \itvs\rm respiratory sensitivities','for HCs \itvs\rm FND patients'};
%tmp_f7.CurrentAxes.Title.FontName = 'Basis Grotesque Pro';
tmp_f7.CurrentAxes.Title.FontWeight = 'Normal';
tmp_f7.CurrentAxes.Title.FontSize = 18;
tmp_f7.CurrentAxes.Title.Position(2) = tmp_f7.CurrentAxes.Title.Position(2)+0.01;

[~,tmp_pval1] = corr(participants_HC.rrst_sensitivity,AUROC2_HC');
[~,tmp_pval2] = corr(participants_FND.rrst_sensitivity,AUROC2_FND');
text(7.5,.65,[' \itp\rm = ' num2str(round(100*tmp_pval2)/100)],'FontSize',14);
text(7.5,.58,[' \itp\rm = ' num2str(round(100*tmp_pval1)/100)],'FontSize',14);

clear tmp_PP tmp_pval1 tmp_pval2;

% Color the FND points by increasing SDQ and add colorbar

tmp_f7.Children(2).Children(5).CData = zeros(length(Participants_FND_names),3); % reset RGB triplets
tmp_cmap1 = flipud(autumn(length(unique(participants_FND.sdq)))); % generate colormap (autumn) with appropriate range
tmp_cmin1 = min(unique(participants_FND.sdq)); tmp_cmax1 = max(unique(participants_FND.sdq)); % find min and max values
tmp_sortedvals1 = sort(unique(participants_FND.sdq));
for j = 1:length(Participants_FND_names) % assign colors within colormap to different P codes (FND group)
    tmp_f7.Children(2).Children(5).CData(j,:) = tmp_cmap1(participants_FND.sdq(j)==tmp_sortedvals1,:);
end
tmp_cbar1 = colorbar(tmp_f7.CurrentAxes); colormap(tmp_cmap1);
caxis([tmp_cmin1 tmp_cmax1]); tmp_cbar1.Label.String = 'SDQ score';
tmp_cbar1.Label.FontSize = 14;
drawnow;
clear tmp_cmap1 tmp_cmin1 tmp_cmax1 tmp_sortedvals1;


%%  Compute aversiveness (task pleasantness), dizziness, breathlessness, and asthma ratings at the end of the experiment
%   between both groups

EndRatings_HC = zeros(4,size(participants_HC,1));
EndRatings_FND= zeros(4,size(participants_FND,1));

tmp_fieldnames = fieldnames(RRSTdata_HC);
for j = 1:size(participants_HC,1)
    if isfield(RRSTdata_HC.(tmp_fieldnames{j}).Results,'ExpRareEnd')
        EndRatings_HC(:,j) = RRSTdata_HC.(tmp_fieldnames{j}).Results.ExpRareEnd(1,1:4)';
    else
        EndRatings_HC(:,j) = NaN; % skip j=2, does not have end of exp. ratings data
    end
end
tmp_fieldnames = fieldnames(RRSTdata_FND);
for j = 1:size(participants_FND,1)
    if isfield(RRSTdata_FND.(tmp_fieldnames{j}).Results,'ExpRareEnd')
        EndRatings_FND(:,j) = RRSTdata_FND.(tmp_fieldnames{j}).Results.ExpRareEnd(1,1:4)';
    else
        EndRatings_FND(:,j) = NaN; % same for j=36
    end
end
clear tmp_fieldnames;

% MANUAL ADJUSTMENTS as per Natascha's email
%EndRatings_FND(1,22) = 0; % this is already 'pleasant' as per data (P40)
EndRatings_FND(:,23) = NaN; % I exclude P42 because it is unclear from the data in the email whether P42 answered wrongly or not
%EndRatings_FND(:,36) = NaN; % this is already NaN from the data (P79), but we cannot add a manual asthma rating from our choice, leave it excluded
EndRatings_FND(1:2,38) = 0; % changing to 0 for P85 (as per email)
EndRatings_FND(4,41) = 40;  % changing to 40 for asthma for P91 (as per email)


%%
tmp_f8 = figure('Position',[600 100 800 800]);
tmp_titles = {'Task Unpleasantness','Dizziness','Breathlessness','Asthma'};
title('Ratings');
for j = 1:4
    subplot(2,2,j);
    boxplot([EndRatings_HC(j,:)';EndRatings_FND(j,:)']',[ones(size(participants_HC,1),1);2*ones(size(participants_FND,1),1)]');
    tmp_gca = gca;
    title(tmp_titles{j},'FontSize',18,'FontWeight','Normal','FontName','Basis Grotesque Pro');
    axis([0.5 2.5 -5 115]); xticks(1:2); yticks(0:10:100);
    tmp_gca.TickLabelInterpreter = 'tex';
    xticklabels({['    HC\newline(n = ' num2str(length(find(~isnan(EndRatings_HC(j,:))))) ')'],...
        ['   FND\newline(n = ' num2str(length(find(~isnan(EndRatings_FND(j,:))))) ')']});
    tmp_gca.FontSize = 14; tmp_gca.YGrid = 'on'; tmp_gca.Box = 'on'; tmp_gca.FontName = 'Basis Grotesque Pro';
    [tmp_h,tmp_pvl] = ttest2(EndRatings_HC(j,:),EndRatings_FND(j,:),'vartype','unequal','alpha',0.05/4);
    line([1 2;1 1;2 2]',[106 106;104.5 106;104.5 106]','Color','bla','LineWidth',1.1);
    text(1.2,101.5,['\itp\rm = ' num2str(round(tmp_pvl*10000)/10000)],'FontSize',11,'FontName','Basis Grotesque Pro');
    if isequal(tmp_h,1), text(1.45,108,'*','FontSize',16,'FontName','Basis Grotesque Pro'); end
end
%clear tmp_gca;


%%  Meta d' (HMeta-d) scores recomputed as per Flemming (2017)

addpath('/Users/nicogn/Documents/MATLAB/HMeta-d-master/CPC_metacog_tutorial/');
addpath('/Users/nicogn/Documents/MATLAB/HMeta-d-master/CPC_metacog_tutorial/cpc_metacog_utils/');
addpath('/Users/nicogn/Documents/MATLAB/HMeta-d-master/Matlab/');       

% recompute % * nR_S1, nR_S2 vectors
% these are vectors containing the total number of responses in
% each response category, conditional on presentation of S1 and S2. S1
% responses are always listed first, followed by S2 responses.
%
% to do that, we need additionally info about which stim (obstructed or
% not) was presented at which trial : in variable 'wheresTheSignal'

nR_S1_FND = zeros(height(participants_FND),2*100+2); % 2*100+2 because there are 101 ratings of confidence ([0,100]) for each stimulus (first S1 then S2), when stimulus S1 was presented
nR_S2_FND = zeros(height(participants_FND),2*100+2); % same as above but for when stimulus S2 was presented (see also 'help fit_meta_d_mcmc')
nR_S1_HC  = zeros(height(participants_HC),2*100+2); % same as above
nR_S2_HC  = zeros(height(participants_HC),2*100+2); % same as above

meta_d_fits_FND = struct;
meta_d_fits_HC  = struct;

% ratings are stored as nR_S1_FND(1,1) := number of times a confidence of 100 was reported when stimulus S1 was correctly guessed
%              and then nR_S1_FND(1,X) := number of times a confidence of   X was reported ...
%              and then nR_S1_FND(1,102) := number of times a confidence of 0 was reported when stimulus S1 was presented but stimulus S2 was answered (i.e., incorrect answer)
%             and so on nR_S1_FND(1,202) := number of times a confidence of 100 was reported when stimulus S1 was presented but stimulus S2 was answered ...

mcmc_params.response_conditional = 0; % Do we want to fit response-conditional meta-d'?
mcmc_params.nchains = 10; % How Many Chains?
mcmc_params.nburnin = 100; % How Many Burn-in Samples?
mcmc_params.nsamples = 500;  %How Many Recorded Samples?
mcmc_params.nthin = 1; % How Often is a Sample Recorded?
mcmc_params.doparallel = 1; % Parallel Option
mcmc_params.dic = 1;  % Save DIC

mcmc_params.estimate_dprime = 1;

for j = 1:height(participants_FND)
    for t = 1:size(Stim_FND,1) % trials
        if isequal(RRSTdata_FND.(Participants_FND_names{j}).vars.wheresTheSignal(t),1) % correct breath was breath 1
            if isequal(Responses_FND(t,j),1) && ~isnan(ConfidenceRatings_FND(j,t)) % participant replied correctly
                nR_S1_FND(j,101-ConfidenceRatings_FND(j,t)) = nR_S1_FND(j,101-ConfidenceRatings_FND(j,t)) + 1; % increase the count at appropriate confidence position
            elseif isequal(Responses_FND(t,j),0) && ~isnan(ConfidenceRatings_FND(j,t)) % participant replied incorrectly (i.e., replied S2 when S1 was correct)
                nR_S1_FND(j,202-(100-ConfidenceRatings_FND(j,t))) = nR_S1_FND(j,202-(100-ConfidenceRatings_FND(j,t))) + 1;
            else, disp(['NaN or error (' num2str(Responses_FND(t,j)) ') for participant ' num2str(j) ' at trial ' num2str(t) '...']);
            end
        elseif isequal(RRSTdata_FND.(Participants_FND_names{j}).vars.wheresTheSignal(t),2) % correct breath was breath 2
            if isequal(Responses_FND(t,j),1) && ~isnan(ConfidenceRatings_FND(j,t)) % participant replied correctly
                nR_S2_FND(j,202-(100-ConfidenceRatings_FND(j,t))) = nR_S2_FND(j,202-(100-ConfidenceRatings_FND(j,t))) + 1;
            elseif isequal(Responses_FND(t,j),0) && ~isnan(ConfidenceRatings_FND(j,t)) % participant replied incorrectly (i.e., replied S1 when S2 was correct)
                nR_S2_FND(j,101-ConfidenceRatings_FND(j,t)) = nR_S2_FND(j,101-ConfidenceRatings_FND(j,t)) + 1; % increase the count at appropriate confidence position
            else, disp(['NaN or error (' num2str(Responses_FND(t,j)) ') for participant ' num2str(j) ' at trial ' num2str(t) '...']);
            end
        end
    end
    % by here the variables nR_S1_FND and nR_S2_FND are computed for each
    % participant, we can proceed with fitting for the meta_d
    meta_d_fits_FND.(Participants_FND_names{j}) = ...
        fit_meta_d_mcmc(nR_S1_FND(j,:), nR_S2_FND(j,:), mcmc_params, [], [], ['tmp_' Participants_FND_names{j}]);
    % fit_meta_d_mcmc(nR_S1, nR_S2, mcmc_params, fncdf, fninv, name);
end

%meta_d_fit_FND_group = fit_meta_d_mcmc(mean(nR_S1_FND), mean(nR_S2_FND), mcmc_params, [], [], 'tmp_group_FND');

for j = 1:height(participants_HC)
    for t = 1:size(Stim_HC,1) % trials
        if isequal(RRSTdata_HC.(Participants_HC_names{j}).vars.wheresTheSignal(t),1) % correct breath was breath 1
            if isequal(Responses_HC(t,j),1) && ~isnan(ConfidenceRatings_HC(j,t)) % participant replied correctly
                nR_S1_HC(j,101-ConfidenceRatings_HC(j,t)) = nR_S1_HC(j,101-ConfidenceRatings_HC(j,t)) + 1; % increase the count at appropriate confidence position
            elseif isequal(Responses_HC(t,j),0) && ~isnan(ConfidenceRatings_HC(j,t)) % participant replied incorrectly (i.e., replied S2 when S1 was correct)
                nR_S1_HC(j,202-(100-ConfidenceRatings_HC(j,t))) = nR_S1_HC(j,202-(100-ConfidenceRatings_HC(j,t))) + 1;
            else, disp(['NaN or error (' num2str(Responses_HC(t,j)) ') for participant ' num2str(j) ' at trial ' num2str(t) '...']);
            end
        elseif isequal(RRSTdata_HC.(Participants_HC_names{j}).vars.wheresTheSignal(t),2) % correct breath was breath 2
            if isequal(Responses_HC(t,j),1) && ~isnan(ConfidenceRatings_HC(j,t)) % participant replied correctly
                nR_S2_HC(j,202-(100-ConfidenceRatings_HC(j,t))) = nR_S2_HC(j,202-(100-ConfidenceRatings_HC(j,t))) + 1;
            elseif isequal(Responses_HC(t,j),0) && ~isnan(ConfidenceRatings_HC(j,t)) % participant replied incorrectly (i.e., replied S1 when S2 was correct)
                nR_S2_HC(j,101-ConfidenceRatings_HC(j,t)) = nR_S2_HC(j,101-ConfidenceRatings_HC(j,t)) + 1; % increase the count at appropriate confidence position
            else, disp(['NaN or error (' num2str(Responses_HC(t,j)) ') for participant ' num2str(j) ' at trial ' num2str(t) '...']);
            end
        end
    end
    % by here the variables nR_S1_HC and nR_S2_HC are computed for each
    % participant, we can proceed with fitting for the meta_d
    meta_d_fits_HC.(Participants_HC_names{j}) = ...
        fit_meta_d_mcmc(nR_S1_HC(j,:), nR_S2_HC(j,:), mcmc_params, [], [], ['tmp_' Participants_HC_names{j}]);
    % fit_meta_d_mcmc(nR_S1, nR_S2, mcmc_params, fncdf, fninv, name);
end

%meta_d_fit_HC_group = fit_meta_d_mcmc(mean(nR_S1_HC), mean(nR_S2_HC), mcmc_params, [], [], 'tmp_group_HC');

%% Plot meta-d or associated metrics (e.g., M_diff)

meta_d_FND = zeros(height(participants_FND),2); % column 1: meta_d ; column 2 : d1
meta_d_HC  = zeros(height(participants_HC),2);  % same as above
for j = 1:height(participants_FND)
    meta_d_FND(j,:) = [meta_d_fits_FND.(Participants_FND_names{j}).meta_d meta_d_fits_FND.(Participants_FND_names{j}).d1];
end
for j = 1:height(participants_HC)
    meta_d_HC(j,:)  = [meta_d_fits_HC.(Participants_HC_names{j}).meta_d meta_d_fits_HC.(Participants_HC_names{j}).d1];
end

boxplot([AUROC2_HC' meta_d_HC(:,1) meta_d_HC(:,2)]); figure;
boxplot([AUROC2_FND' meta_d_FND(:,1) meta_d_FND(:,2)]);











































% APPENDIX
% (Modified; NG)
% Matlab code for calculating the area under the type 2 ROC (Fleming & Lau, 2014)

function [auroc2,cum_H2,cum_FA2] = type2roc(correct, conf, Nratings)
% function auroc2 = type2roc(correct, conf, Nratings)
%
% Calculate area under type 2 ROC
%
% correct - vector of 1 x ntrials, 0 for error, 1 for correct
% conf - vector of 1 x ntrials of confidence ratings taking values 1:Nratings
% Nratings - how many confidence levels available

    %conf(isnan(conf)) = -1; % tweak to skip NaNs
    correct(isnan(correct)) = -1; % tweak to skip NaNs as well
    
    i = Nratings+1;
    for c = 1:Nratings
        H2(i-1) = length(find(conf == c & correct)) + 0.5;
        FA2(i-1) = length(find(conf == c & ~correct)) + 0.5;
        i = i-1;
    end
    
    H2 = H2./sum(H2);
    FA2 = FA2./sum(FA2);
    cum_H2 = [0 cumsum(H2)];
    cum_FA2 = [0 cumsum(FA2)];
    
    i=1;
    for c = 1:Nratings
        k(i) = (cum_H2(c+1) - cum_FA2(c))^2 - (cum_H2(c) - cum_FA2(c+1))^2;
        i = i+1;
    end
    
    auroc2 = 0.5 + 0.25*sum(k);

end

